BY: DYLAN CAMPBELL

HOW TO RUN:

* Make sure the input file is named �input_words.txt� and placed in the same directory as the �words_extractor.py�

* run �python words_extractor.py� while in the containing directory on the command line.

* output will be in the �extracted_words.txt� in the same directory. 
