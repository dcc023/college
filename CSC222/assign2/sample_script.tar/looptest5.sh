#!/bin/sh
for foo in 1 1 1 1 1 1 1 1 1 1
do
  echo “here we go again”
done
exit 0

