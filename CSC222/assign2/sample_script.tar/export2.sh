#!/bin/sh
foo="The first meta-syntactic variable"
export bar="The second meta-syntactic variable"
echo "$foo"
echo "$bar"
