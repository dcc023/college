#!/bin/sh
for i in 1 2
do
  echo  $i_tmp
done
