#!/bin/sh
for i in "$@"; do
echo arg: '$i'
done
	
