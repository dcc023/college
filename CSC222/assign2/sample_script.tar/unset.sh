#!/bin/sh

foo="Hello World"
echo $foo

unset $foo
echo $foo
