#!/bin/sh

echo the date is $(date)
set $(date)
echo The month is $2

exit 0
