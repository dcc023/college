#!/bin/sh

echo the who is $(who)
set $(who)
echo The month is $2

exit 0
