#!/bin/sh
for foo in 1 2 3 4 5 6 7 8 9 10
do
  echo "here we go again"
done
exit 0

