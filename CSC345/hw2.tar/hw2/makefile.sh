gcc -o fork fork.c

./fork
